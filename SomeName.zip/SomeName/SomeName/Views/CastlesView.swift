//
//  CastlesView.swift
//  SomeName
//
//  Created by user252958 on 3/17/24.
//

import SwiftUI

struct CastlesView: View {
    
    let castles: [Game]
    @State var somestr = ""
    
    var body: some View {
        ScrollView {
            ForEach(castles) { castle in
                NavigationLink(value: castle) {
                    CastleView(castle: castle)
                }
            }
            .navigationDestination(for: Game.self) {castle in
                CastleScreenView(castle: castle)
            }
        }
    }
}

#Preview {
    CastlesView(castles: [
        Game(id: "1", name: "First", imageName: "castle", releaseYear: 1022, description: "Belarus"),
        Game(id: "2", name: "Second", imageName: "castle", releaseYear: 2933, description: "Belarus"),
    ])
}
