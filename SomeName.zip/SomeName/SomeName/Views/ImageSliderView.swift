//
//  ImageSlider.swift
//  SomeName
//
//  Created by user252958 on 3/25/24.
//

import SwiftUI

struct ImageSliderView: View {
    
    let images: [String]
    
    var body: some View {
        TabView {
            ForEach(images, id: \.self) { item in
                AsyncImage(url: URL(string: item)) { image in
                    image.resizable()
                } placeholder: {
                    ProgressView()
                }
                
            }
        }
        .tabViewStyle(PageTabViewStyle())
        .frame(width: 350, height: 300)
        .cornerRadius(50)
    }
}
#Preview {
    ImageSliderView(images: [				
        "https://belarusgid.com/wp-content/uploads/2015/05/IMG_0845.jpg",
        "https://hips.hearstapps.com/hmg-prod/images/bojnice-castle-1603142898.jpg?crop=0.668xw:1.00xh;0.116xw,0&resize=980:*"
    ])
}
