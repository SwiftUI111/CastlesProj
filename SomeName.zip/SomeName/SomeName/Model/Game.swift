//
//  Castle.swift
//  SomeName
//
//  Created by user252958 on 3/17/24.
//

import Foundation

struct Game: Identifiable, Hashable {
    var id: String = ""
    var name: String
    var imageName: String
    var releaseYear: Int
    var description: String
}
