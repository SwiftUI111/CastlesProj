//
//  User.swift
//  SomeName
//
//  Created by user252958 on 3/20/24.
//

import Foundation

struct User {
    
    var id: String = ""
    
    let email: String
    
    let firstName: String
    
    let lastName: String
    
    let bio: String
    
    let birthDate: Date
    
}
