//
//  SignUpViewModel.swift
//  SomeName
//
//  Created by user252958 on 3/20/24.
//

import Foundation
import FirebaseAuth
import FirebaseFirestore

import SwiftUI

@MainActor
class SignUpViewModel: ObservableObject {
    
    
    @Published var email: String = ""
    
    @Published var firstName: String = ""
    
    @Published var lastName: String = ""
    
    @Published var password: String = ""
    
    @Published var bio: String = ""
    
    @Published var confirmationPassword: String = ""
    
    @Published var birthdate = Date()
    
    private let router = Router.shared

    func signUp() {
        var user = User(
            email: email,
            firstName: firstName,
            lastName: lastName,
            bio: bio,
            birthDate: birthdate
        )
        
        Auth.auth().createUser(withEmail: user.email, password: password) { authResult, error in
            if (error == nil && authResult != nil) {
                let id = authResult?.user.uid ?? ""
                user.id = id
                self.createUser(user: user)
            }
        }
    }
    
    func createUser(user: User) {
        Firestore.firestore().collection("users")
            .document(user.id)
            .setData([
                "firstName": user.firstName,
                "lastName": user.lastName,
                "bio": user.bio,
                "birthdate": user.birthDate
            ])
        
        toLoginScreen()
    }
    
    func toLoginScreen() {
        router.navigate(to: .login)
    }
}
