//
//  FavoritesViewModel.swift
//  SomeName
//
//  Created by user252958 on 3/24/24.
//

import Foundation
import FirebaseFirestore

@MainActor
class FavoritesViewModel: ObservableObject {

    @Published var favoriteCastles: [Game] = []
    
    func loadCastles() async {
        favoriteCastles.removeAll()
        
        do {
            let snapshot = try await Firestore.firestore()
                .collection("users")
                .document(UserManager.shared.user!.id)
                .collection("favorites")
                .getDocuments()
            
            var castlesIds: [String] = []
            for doc in snapshot.documents {
                castlesIds.append(doc.documentID)
            }
            
            guard !castlesIds.isEmpty else { return }
                
            let snapshot2 = try await Firestore.firestore()
                .collection("games")
                .whereField(FieldPath.documentID(), in: castlesIds)
                .getDocuments()
            
            for document in snapshot2.documents {
                let id = document.documentID
                let name = document.get("name") as! String
                let country = document.get("description") as! String
                let foundationYear = document.get("releaseYear") as! Int
                let mainImage = document.get("mainImage") as! String
                
                let castle = Game(id: id, name: name, imageName: mainImage, releaseYear: foundationYear, description: country)
                favoriteCastles.append(castle)
            }
        } catch {
            
        }
    }
    
}
