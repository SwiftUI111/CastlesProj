//
//  CastlesViewModel.swift
//  SomeName
//
//  Created by user252958 on 3/22/24.
//

import Foundation
import FirebaseCore
import FirebaseFirestore

@MainActor
class CastlesViewModel: ObservableObject {
    
    @Published private var castles: [Game] = []
    
    @Published var searchText = ""
    
    var filteredCasltes: [Game] {
        if searchText.isEmpty {
            return castles
        }
        
        return castles.filter { $0.name.localizedCaseInsensitiveContains(searchText) }
    }
    
    func loadCastles() async {
        castles.removeAll()
        
        do {
            let snapshot = try await Firestore
                .firestore()
                .collection("games")
                .getDocuments()
            
            for document in snapshot.documents {
                let id = document.documentID
                let name = document.get("name") as! String
                let country = document.get("description") as! String
                let foundationYear = document.get("releaseYear") as! Int
                let mainImage = document.get("mainImage") as! String
                
                let castle = Game(id: id, name: name, imageName: mainImage, releaseYear: foundationYear, description: country)
                castles.append(castle)
            }
        } catch {
            
        }
    }
    
}
