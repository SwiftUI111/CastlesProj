//
//  Router.swift
//  SomeName
//
//  Created by user252958 on 3/22/24.
//

import Foundation
import SwiftUI

@MainActor
class Router: ObservableObject {
    
    static let shared = Router()
    
    public enum Destination: Codable, Hashable {
        case login
        case registration
        case app
    }
    
    @Published var navPath = NavigationPath()
    
    func navigate(to destination: Destination) {
        navPath.append(destination)
    }
    
    func navigateBack() {
        navPath.removeLast()
    }
    
    func navigateToRoot() {
        navPath.removeLast(navPath.count)
    }
    
}
