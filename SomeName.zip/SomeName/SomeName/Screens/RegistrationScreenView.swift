//
//  RegistrationView.swift
//  SomeName
//
//  Created by user252958 on 3/13/24.
//

import SwiftUI

struct RegistrationScreenView: View {
    @StateObject var signUpViewModel = SignUpViewModel()
    
    var body: some View {
        let myFont = Font.custom("MyFont", size: 22)
        
        ZStack {
            VStack {
                Text("Credentials:")
                    .multilineTextAlignment(.leading)
                    .font(myFont)
                    .bold()
                
                TextField(
                    text: $signUpViewModel.email,
                    prompt: Text("Input your email")
                ) {
                }
                .textFieldStyle(.roundedBorder)
                .autocapitalization(.none)
                .border(Color.gray)
                .frame(
                    width: 300,
                    height: 50
                )
                
                SecureField(
                    text: $signUpViewModel.password,
                    prompt: Text("Input your password")
                ) {
                }
                .textFieldStyle(.roundedBorder)
                .border(Color.gray)
                .frame(
                    width: 300,
                    height: 50
                )
                
                SecureField(
                    text: $signUpViewModel.confirmationPassword,
                    prompt: Text("Input your password again")
                ) {                }
                .textFieldStyle(.roundedBorder)
                .border(Color.gray)
                .frame(
                    width: 300,
                    height: 50
                )
                
                Text("Personal info:")
                    .multilineTextAlignment(.leading)
                    .font(myFont)
                    .bold()
                
                TextField(
                    text: $signUpViewModel.firstName,
                    prompt: Text("Input your first name")
                ) {
                }
                .textFieldStyle(.roundedBorder)
                .border(Color.gray)
                .frame(
                    width: 300,
                    height: 50
                )
                
                TextField(
                    text: $signUpViewModel.lastName,
                    prompt: Text("Input your last name")
                ) {
                }
                .textFieldStyle(.roundedBorder)
                .border(Color.gray)
                .frame(
                    width: 300,
                    height: 50
                )
                
                TextField(
                    text: $signUpViewModel.bio,
                    prompt: Text("Input your bio")
                ) {
                }
                .lineLimit(3)
                .textFieldStyle(.roundedBorder)
                .border(Color.gray)
                .frame(
                    width: 300,
                    height: 50
                )
                
                DatePicker(
                    "Your birthdate:",
                    selection: $signUpViewModel.birthdate,
                    in: PartialRangeThrough(Date()),
                    displayedComponents: [.date]
                )
                .foregroundColor(.primary)
                .frame(
                    width: 300,
                    height: 40
                )
                .background()
                
                Text(
                    "Have an account?"
                )
                .underline()
                .onTapGesture {
                    signUpViewModel.toLoginScreen()
                }
                
                Button(
                    action: {
                        signUpViewModel.signUp()
                    }
                ) {
                    Text("Sign up")
                }
                .buttonStyle(.borderedProminent)
            }
        }
    }
}

#Preview {
    RegistrationScreenView()
}
