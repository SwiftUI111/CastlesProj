//
//  FavoritesScreenView.swift
//  SomeName
//
//  Created by user252958 on 3/24/24.
//

import SwiftUI

struct FavoritesScreenView: View {
    
    @StateObject var favoritesViewModel = FavoritesViewModel()
    
    var body: some View {
        ScrollView {
            VStack {
                Text("Favorites")
                    .font(.system(size: 30))
                    .bold()
                
                CastlesView(castles: favoritesViewModel.favoriteCastles)
            }
            .onAppear(perform: {
                Task {
                    await favoritesViewModel.loadCastles()
                }
            })
        }
    }
}

#Preview {
    FavoritesScreenView()
}
