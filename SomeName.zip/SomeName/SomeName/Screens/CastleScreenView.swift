	//
//  CastleView.swift
//  SomeName
//
//  Created by user252958 on 3/17/24.
//

import SwiftUI

struct CastleScreenView: View {
    
    @ObservedObject var castleViewModel: CastleViewModel = CastleViewModel()
    
    init(castle: Game) {
        castleViewModel.setCastle(castle: castle)
    }
    
    var body: some View {
        ScrollView {
            VStack {
                Text(castleViewModel.castle.name)
                    .font(.title)
                    .bold()
                
                ImageSliderView(images: castleViewModel.images)
                
                Text("Description: " + castleViewModel.castle.description)
                Text("Release year: " + String(castleViewModel.castle.releaseYear))
                
                if !castleViewModel.isReviewPresent {
                    Text("Make your review")
                        .font(/*@START_MENU_TOKEN@*/.title/*@END_MENU_TOKEN@*/)
                        .bold()
                    
                    Slider(
                        value: $castleViewModel.rate,
                        in: 0...10,
                        step: 1
                    )
                    .frame(
                        width: 330
                    )
                    
                    Text("\(Int(castleViewModel.rate))")
                    
                    TextEditor(text: $castleViewModel.comment)
                        .frame(
                            width: 350,
                            height: 150
                        )
                        .foregroundStyle(.blue)
                        .colorMultiply(Color(red: 0.7578125, green: 0.7578125, blue: 0.92578125))                .cornerRadius(10)
                    
                    Button("Make review") {
                        Task {
                            await castleViewModel.addReview()
                        }
                    }
                    .buttonStyle(.borderedProminent)
                }
                Button(
                    action: {
                        Task {
                            await castleViewModel.onLikeButtonPress()
                        }
                    }
                ) {
                    let symbolVariant: SymbolVariants = castleViewModel.isInFavorites ? .fill : .none
                    Image(systemName: "heart")
                        .foregroundColor(.red)
                        .imageScale(.large)
                        .symbolVariant(symbolVariant)
                }
                    
                Text("Reviews")
                    .font(/*@START_MENU_TOKEN@*/.title/*@END_MENU_TOKEN@*/)
                    .bold()
                
                ForEach(castleViewModel.reviews, id: \Review.userName) { review in
                    
                    VStack {
                        HStack {
                            Text(review.userName)
                            Text(String(review.rate))
                                .foregroundStyle(.red)
                        }
                        Text(review.comment)
                            .fontWeight(/*@START_MENU_TOKEN@*/.bold/*@END_MENU_TOKEN@*/)
                    }
                    .frame(width: 300)
                    .padding()
                    .border(.black, width: 2)
                }
            }
        }
        .onAppear() {
            Task {
                await castleViewModel.loadInfo()
            }
        }
    }
}

#Preview {
    CastleScreenView(
        castle: Game(
            id: "CJBxsNN0MvrSzlzyoA3i",
            name: "CastleName",
            imageName: "https://belarusgid.com/wp-content/uploads/2015/05/IMG_0845.jpg",
            releaseYear: 11,
            description: "CountryName"
        )
    )
}
