//
//  CastlesScreenView.swift
//  SomeName
//
//  Created by user252958 on 3/20/24.
//

import SwiftUI

struct CastlesScreenView: View {
    
    @StateObject var castlesViewModel = CastlesViewModel()
    
    var body: some View {
        VStack {
            Text("Games")
                .font(.system(size: 30))
                .bold()
            
            SearchBarView(searchText: $castlesViewModel.searchText)
            
            CastlesView(castles: castlesViewModel.filteredCasltes)
        }
        .onAppear(perform: {
            Task {
                await castlesViewModel.loadCastles() 
            }
        })
    }
}

#Preview {
    CastlesScreenView()
}
