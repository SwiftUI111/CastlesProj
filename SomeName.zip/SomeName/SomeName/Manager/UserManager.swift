//
//  UserManager.swift
//  SomeName
//
//  Created by user252958 on 3/24/24.
//

import Foundation

class UserManager {
    
    static let shared = UserManager()
    
    var user: User? = User(id: "l0QHwr0Akpf9cRpVm9R91Ig4zJw2", email: "someemail", firstName: "FirstName", lastName: "LastName", bio: "something", birthDate: Date())
    
}
