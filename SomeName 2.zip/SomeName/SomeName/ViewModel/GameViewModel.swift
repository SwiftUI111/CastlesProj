//
//  CastleViewModel.swift
//  SomeName
//
//  Created by user252958 on 3/23/24.
//

import Foundation
import SwiftUI
import FirebaseFirestore

@MainActor
class GameViewModel: ObservableObject {

    @Published var rate = 5.0
    
    @Published var comment = ""
    
    @Published var isReviewPresent = true

    @Published var game: Game = Game(name: "", imageName: "", releaseYear: 0, description: "")

    @Published var isInFavorites: Bool = false
    
    @Published var reviews: [Review] = []
    
    @Published var images: [String] = []
    
    func setGame(game: Game) {
        self.game = game
    }
    
    private func loadIsInFavoritesInfo() async {
        do {
            isInFavorites = try await Firestore.firestore()
                .collection("users")
                .document(UserManager.shared.user!.id)
                .collection("favorites")
                .document(game.id)
                .getDocument()
                .exists
        } catch {
            isInFavorites = false
        }
    }
    
    private func loadIsReviewPresent() async {
        let user = UserManager.shared.user!
        
        do {
            isReviewPresent = try await Firestore.firestore()
                .collection("games")
                .document(game.id)
                .collection("reviews")
                .document(user.id)
                .getDocument()
                .exists
        } catch {
            isReviewPresent = false
        }
    }
    
    private func loadReviews() async {
        do {
            let snapshot = try await Firestore.firestore()
                .collection("games")
                .document(game.id)
                .collection("reviews")
                .getDocuments()
            
            for doc in snapshot.documents {
                let rate = doc.get("rate") as! Int
                let comment = doc.get("comment") as! String
                let userName = doc.get("userName") as! String
                
                let review = Review(rate: rate, comment: comment, userName: userName)
                reviews.append(review)
            }
        } catch {
            print("Error getting documents: \(error)")
        }
    }
    
    private func loadImages() async {
        do {
            let snapshot = try await Firestore.firestore()
                .collection("games")
                .document(game.id)
                .collection("images")
                .getDocuments()
            
            for doc in snapshot.documents {
                let url = doc.get("url") as! String
                images.append(url)
            }
        } catch {
            print("Error getting documents: \(error)")
        }
    }
    
    func loadInfo() async {
        await loadIsInFavoritesInfo()
        await loadIsReviewPresent()
        await loadReviews()
        await loadImages()
    }
    
    func onLikeButtonPress() async {
        if isInFavorites {
            await removeFromFavorites()
        } else {
            await addToFavorites()
        }
    }
    
    private func addToFavorites() async {
        do {
            try await Firestore.firestore()
                .collection("users")
                .document(UserManager.shared.user!.id)
                .collection("favorites")
                .document(game.id)
                .setData([:])
            
            isInFavorites = true
        } catch {
        }
    }
    
    private func removeFromFavorites() async {
        do {
            try await Firestore.firestore()
                .collection("users")
                .document(UserManager.shared.user!.id)
                .collection("favorites")
                .document(game.id)
                .delete()
            
            isInFavorites = false
        } catch {
        }
    }
    
    func addReview() async {
        let user = UserManager.shared.user!
        let rate = Int(self.rate)
        let userName = user.lastName + " " + user.firstName
        
        do {
            try await Firestore.firestore()
                .collection("games")
                .document(game.id)
                .collection("reviews")
                .document(user.id)
                .setData([
                    "rate": rate,
                    "comment": comment,
                    "userName": userName
                ])
            
            isReviewPresent = true
            
            reviews.append(Review(rate: rate, comment: comment, userName: userName))
        } catch {
        }
    }
}
