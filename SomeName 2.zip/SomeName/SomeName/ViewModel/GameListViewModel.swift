//
//  CastlesViewModel.swift
//  SomeName
//
//  Created by user252958 on 3/22/24.
//

import Foundation
import FirebaseCore
import FirebaseFirestore

@MainActor
class GameListViewModel: ObservableObject {
    
    @Published private var games: [Game] = []
    
    @Published var searchText = ""
    
    var getFilteredGames: [Game] {
        if searchText.isEmpty {
            return games
        }
        
        return games.filter { $0.name.localizedCaseInsensitiveContains(searchText) }
    }
    
    func loadGames() async {
        games.removeAll()
        
        do {
            let snapshot = try await Firestore
                .firestore()
                .collection("games")
                .getDocuments()
            
            for document in snapshot.documents {
                let id = document.documentID
                let name = document.get("name") as! String
                let country = document.get("description") as! String
                let foundationYear = document.get("releaseYear") as! Int
                let mainImage = document.get("mainImage") as! String
                
                let game = Game(id: id, name: name, imageName: mainImage, releaseYear: foundationYear, description: country)
                games.append(game)
            }
        } catch {
            
        }
    }
    
}
