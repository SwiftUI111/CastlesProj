//
//  ProfileViewModel.swift
//  SomeName
//
//  Created by user252958 on 3/22/24.
//

import Foundation

@MainActor
class ProfileViewModel: ObservableObject {
    
    private let router = Router.shared

    private let userManager = UserManager.shared
    
    var name: String {
        return userManager.user!.firstName + " " + userManager.user!.lastName
    }
    
    var bio: String {
        return userManager.user!.bio
    }
    
    var email: String {
        return userManager.user!.email
    }
    
    var birthdate: String {
        return dateToString(date: userManager.user!.birthDate)
    }
    
    private func dateToString(date: Date) -> String {
        let dateFormatter = DateFormatter()
        dateFormatter.dateFormat = "dd.MM.YYYY"
        return dateFormatter.string(from: date)
    }
    
    func logOut() {
        UserManager.shared.user = nil
        router.navigate(to: .login)
    }
    
}
