//
//  SignInViewModel.swift
//  SomeName
//
//  Created by user252958 on 3/20/24.
//

import Foundation
import SwiftUI
import FirebaseAuth
import FirebaseFirestore

@MainActor
class SignInViewModel: ObservableObject {
 
    private let router = Router.shared
    
    @Published var email: String = ""
    
    @Published var password: String = ""
    
    func signIn() async {
        do {
            try await Auth.auth().signIn(withEmail: email, password: password)
            
            let id = Auth.auth().currentUser!.uid
            
            let snapshot = try await Firestore.firestore()
                .collection("users")
                .document(id)
                .getDocument()
            
            let bio = snapshot.get("bio") as! String
            let birthdateTimestamp = snapshot.get("birthdate") as! Timestamp
            let firstName = snapshot.get("firstName") as! String
            let lastName = snapshot.get("lastName") as! String
            
            UserManager.shared.user = User(id: id, email: email, firstName: firstName, lastName: lastName, bio: bio, birthDate: birthdateTimestamp.dateValue())
            
            router.navigate(to: .app)
        } catch {
            print("Error getting documents: \(error)")
        }
    }
    
    func toSignUp() {
        router.navigate(to: .registration)
    }
    
}
