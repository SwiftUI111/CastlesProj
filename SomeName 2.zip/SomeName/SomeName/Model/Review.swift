//
//  Review.swift
//  SomeName
//
//  Created by user252958 on 3/24/24.
//

import Foundation

struct Review {
    
    let rate: Int
    
    let comment: String
    
    let userName: String
    
}
