//
//  ContentView.swift
//  SomeName
//
//  Created by user252958 on 3/20/24.
//

import SwiftUI

struct ContentView: View {
    
    @ObservedObject var router = Router.shared
    
    var body: some View {
        NavigationStack(path: $router.navPath) {
            LoginScreenView()
            .navigationDestination(for: Router.Destination.self) { destination in
                switch destination {
                case .login:
                    LoginScreenView()
                        .navigationBarBackButtonHidden(true)
                case .app:
                    AppScreenView()
                        .navigationBarBackButtonHidden(true)
                case .registration:
                    RegistrationScreenView()
                        .navigationBarBackButtonHidden(true)
                }
            
            }
        }
    }
    
}

#Preview {
    ContentView()
}
