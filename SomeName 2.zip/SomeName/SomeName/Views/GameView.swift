//
//  CastleView.swift
//  SomeName
//
//  Created by user252958 on 3/17/24.
//

import SwiftUI

struct GameView: View {
    
    let game: Game
    
    var body: some View {
        VStack {
            AsyncImage(url: URL(string: game.imageName)) { image in
                image.resizable()
            } placeholder: {
                ProgressView()
            }
            .frame(width: 350, height: 300)
            .cornerRadius(50)
	
            Text(game.name)
                .font(.system(size: 25))
        }
    }
}

#Preview {
    GameView(
        game: Game(
            name: "CastleName",
            imageName: "https://belarusgid.com/wp-content/uploads/2015/05/IMG_0845.jpg",
            releaseYear: 11,
            description: "CountryName"
        )
    )
}
