//
//  CastlesView.swift
//  SomeName
//
//  Created by user252958 on 3/17/24.
//

import SwiftUI

struct GameListView: View {
    
    let games: [Game]
    @State var somestr = ""
    
    var body: some View {
        ScrollView {
            ForEach(games) { game in
                NavigationLink(value: game) {
                    GameView(game: game)
                }
            }
            .navigationDestination(for: Game.self) {game in
                GameScreenView(game: game)
            }
        }
    }
}

#Preview {
    GameListView(games: [
        Game(id: "1", name: "First", imageName: "my game", releaseYear: 2022, description: "First one"),
        Game(id: "2", name: "Second", imageName: "game2", releaseYear: 2023, description: "Second one"),
    ])
}
