//
//  ImageSlider.swift
//  SomeName
//
//  Created by user252958 on 3/25/24.
//

import SwiftUI

struct ImageSliderView: View {
    
    let images: [String]
    
    var body: some View {
        TabView {
            ForEach(images, id: \.self) { item in
                AsyncImage(url: URL(string: item)) { image in
                    image.resizable()
                } placeholder: {
                    ProgressView()
                }
                
            }
        }
        .tabViewStyle(PageTabViewStyle())
        .frame(width: 350, height: 300)
        .cornerRadius(50)
    }
}
#Preview {
    ImageSliderView(images: [				

    ])
}
