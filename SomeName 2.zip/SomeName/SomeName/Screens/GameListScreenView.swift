//
//  CastlesScreenView.swift
//  SomeName
//
//  Created by user252958 on 3/20/24.
//

import SwiftUI

struct GameListScreenView: View {
    
    @StateObject var gameListViewModel = GameListViewModel()
    
    var body: some View {
        VStack {
            Text("Games")
                .font(.system(size: 30))
                .bold()
            
            SearchBarView(searchText: $gameListViewModel.searchText)
            
            GameListView(games: gameListViewModel.getFilteredGames)
        }
        .onAppear(perform: {
            Task {
                await gameListViewModel.loadGames() 
            }
        })
    }
}

#Preview {
    GameListScreenView()
}
