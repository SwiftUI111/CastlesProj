	//
//  CastleView.swift
//  SomeName
//
//  Created by user252958 on 3/17/24.
//

import SwiftUI

struct GameScreenView: View {
    
    @ObservedObject var gameViewModel: GameViewModel = GameViewModel()
    
    init(game: Game) {
        gameViewModel.setGame(game: game)
    }
    
    var body: some View {
        ScrollView {
            VStack {
                Text(gameViewModel.game.name)
                    .font(.title)
                    .bold()
                
                ImageSliderView(images: gameViewModel.images)
                
                Text("Description: " + gameViewModel.game.description)
                Text("Release year: " + String(gameViewModel.game.releaseYear))
                
                if !gameViewModel.isReviewPresent {
                    Text("Make your review")
                        .font(/*@START_MENU_TOKEN@*/.title/*@END_MENU_TOKEN@*/)
                        .bold()
                    
                    Slider(
                        value: $gameViewModel.rate,
                        in: 0...10,
                        step: 1
                    )
                    .frame(
                        width: 330
                    )
                    
                    Text("\(Int(gameViewModel.rate))")
                    
                    TextEditor(text: $gameViewModel.comment)
                        .frame(
                            width: 350,
                            height: 150
                        )
                        .foregroundStyle(.blue)
                        .colorMultiply(Color(red: 0.7578125, green: 0.7578125, blue: 0.92578125))                .cornerRadius(10)
                    
                    Button("Make review") {
                        Task {
                            await gameViewModel.addReview()
                        }
                    }
                    .buttonStyle(.borderedProminent)
                }
                Button(
                    action: {
                        Task {
                            await gameViewModel.onLikeButtonPress()
                        }
                    }
                ) {
                    let symbolVariant: SymbolVariants = gameViewModel.isInFavorites ? .fill : .none
                    Image(systemName: "heart")
                        .foregroundColor(.red)
                        .imageScale(.large)
                        .symbolVariant(symbolVariant)
                }
                    
                Text("Reviews")
                    .font(/*@START_MENU_TOKEN@*/.title/*@END_MENU_TOKEN@*/)
                    .bold()
                
                ForEach(gameViewModel.reviews, id: \Review.userName) { review in
                    
                    VStack {
                        HStack {
                            Text(review.userName)
                            Text(String(review.rate))
                                .foregroundStyle(.red)
                        }
                        Text(review.comment)
                            .fontWeight(/*@START_MENU_TOKEN@*/.bold/*@END_MENU_TOKEN@*/)
                    }
                    .frame(width: 300)
                    .padding()
                    .border(.black, width: 2)
                }
            }
        }
        .onAppear() {
            Task {
                await gameViewModel.loadInfo()
            }
        }
    }
}

#Preview {
    GameScreenView(
        game: Game(
            id: "CJBxsNN0MvrSzlzyoA3i",
            name: "CastleName",
            imageName: "https://belarusgid.com/wp-content/uploads/2015/05/IMG_0845.jpg",
            releaseYear: 11,
            description: "CountryName"
        )
    )
}
