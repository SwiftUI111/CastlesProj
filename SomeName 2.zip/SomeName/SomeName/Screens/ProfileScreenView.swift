//
//  ProfileView.swift
//  SomeName
//
//  Created by user252958 on 3/17/24.
//

import SwiftUI

struct ProfileScreenView: View {
    
    @StateObject var profileViewModel = ProfileViewModel()

    
    var body: some View {
        VStack {
            Form {
                Section("email") {
                    Text(profileViewModel.email)
                        .font(.system(size: 22))
                        .bold()
                }
                
                Section("Name") {
                    Text(profileViewModel.name)
                        .font(.system(size: 22))
                        .bold()
                }
                
                Section("bio") {
                    Text(profileViewModel.bio   )
                        .font(.system(size: 22))
                        .bold()
                }
                
                Section("birth date") {
                    Text(profileViewModel.birthdate)
                        .font(.system(size: 22))
                        .bold()
                }
            }
            .frame(height: 400)
            
            Button(
                action: {
                    profileViewModel.logOut()
                }
            ) {
                Text("Logout")
            }
            .buttonStyle(.borderedProminent)
        }
    }
}

#Preview {
    ProfileScreenView()
}
