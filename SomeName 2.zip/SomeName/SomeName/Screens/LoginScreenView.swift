//
//  ContentView.swift
//  SomeName
//
//  Created by user252958 on 3/13/24.
//

import SwiftUI
import FirebaseAuth
import FirebaseCore

struct LoginScreenView: View {

    @StateObject var signInViewModel = SignInViewModel()
    
    var body: some View {
        VStack {
            Text("Welcome!")
                .multilineTextAlignment(.leading)
                .font(.system(size: 26, weight: .bold))
            
            TextField(
                "Input your email",
                text: $signInViewModel.email
            ){
            }
            .frame(
                width: 300,
                height: 20
            )
            .padding()
            .border(Color.gray)
            .autocapitalization(.none)
        

            SecureField(
                "Input your password",
                text: $signInViewModel.password
            ){
            }
            .frame(
                width: 300,
                height: 20
            )
            .padding()
            .border(Color.gray)
            .autocapitalization(.none)
        }
        
        Text("Have no account?")
            .underline()
            .onTapGesture {
                signInViewModel.toSignUp()
            }
        
        Button(
            "Sign in"
        ) {
            Task {
                await signInViewModel.signIn()
            }
        }
        .buttonStyle(.borderedProminent)
        
    }
}

#Preview {
    LoginScreenView()
}
