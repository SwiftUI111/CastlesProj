//
//  AppScreenVIew.swift
//  SomeName
//
//  Created by user252958 on 3/22/24.
//

import SwiftUI

struct AppScreenView: View {

    var body: some View {
        TabView {
            ProfileScreenView()
                .tabItem {
                    Label("Profile", systemImage: "person")
                }
            
            GameListScreenView()
                .tabItem {
                    Label("Games", systemImage: "house")
                }

            FavoritesScreenView()
                .tabItem {
                    Label("Favorites", systemImage: "heart")
                }
        }
    }
}

struct AppScreenViewWrapper: View {
    var body: some View {
        AppScreenView()
    }
}

struct AppScreenPreview: PreviewProvider {
    
    static var previews: some View {
        AppScreenViewWrapper()
    }
}
