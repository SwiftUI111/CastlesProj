//
//  Screen.swift
//  SomeName
//
//  Created by user252958 on 3/21/24.
//

import Foundation

enum Screen {
    case login
    case registration
    case games
    case game
    case profile
}
